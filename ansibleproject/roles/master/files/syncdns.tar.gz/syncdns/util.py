import logging
import hashlib
import os
import time
import commands
import json
from command_table import cmd_tbl

debug = logging.DEBUG
info = logging.INFO
warning = logging.WARNING
error = logging.ERROR
critical = logging.CRITICAL

#sshflag = " -o ConnectTimeout=5 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -q  "
sshflag = " -o ConnectTimeout=5 -o LogLevel=error "  
def getssh(host_os):
  return getcmd('ssh',host_os) + sshflag

#use the following for cross server rsync, execute at master
def getxrsync(host_os):
  return getcmd('rsync', host_os)

def getsudocmd(account_str, host_os):
  sudo = getcmd('sudo', host_os)
  return sudo + ' -u ' + getappuser(account_str)

def getsudobytype(account_str,host_os,type):  
  if 'APN' in type:
    return getsudocmd(account_str,host_os) + ' '
  else:
    return ''

def getsudo(account_str,host_os, type, owner):
  if owner == None or owner.strip() == '' or (owner.strip() != 'non-Root' and owner.strip() != 'Root'):
    return getsudobytype(account_str,host_os,type) 
  if 'non-Root' in owner:
    return getsudocmd(account_str, host_os) + ' '
  else:
    return ''
 
# only when meta driven not fully implemented 
def getrsyncbytype(host_os, type, account_str):
  if 'APN' in type and 'Sun' in host_os:   
    return getsudobytype(account_str,host_os, type) +" /usr/localcw/bin/rsync"    
  elif 'APN' in type:
    return getsudobytype(account_str,host_os, type) +" /usr/bin/rsync"
  elif 'Sun' in host_os:
    return "/usr/localcw/bin/rsync"
  else:
    return "/usr/bin/rsync"
    
# use the following for local sync at target 
def getrsync(host_os, type, owner, account_str): 
  sudo = getsudo(account_str,host_os,type,owner)
  rsync = getcmd('rsync',host_os)
  return sudo + rsync

# only when meta driven not fully implemented 
def getrrsynckeybytype(type,account_str):  
  account = json.loads(account_str)
  return account['rrsync-key'] if type == 'IXC' else account['srsync-key']

def getrrsynckey(type, owner, account_str): 
  if owner == None or owner.strip() == '' or (owner.strip() != 'non-Root' and owner.strip() != 'Root'):
    return getrrsynckeybytype(type,account_str)
  account = json.loads(account_str)
  if 'non-Root' in owner:        
    return account['srsync-key']
  elif 'Root' in owner:
    return account['rrsync-key']

def getdefaultkey(account_str):
  account = json.loads(account_str)
  return account['default-key']

def getappuser(account_str):
  account = json.loads(account_str)
  return account['app']
  
def gettar(host_os, type, owner, account_str):
  sudo = getsudo(account_str,host_os, type, owner)
  tar = getcmd('tar', host_os)
  return sudo + tar
      
def getmkdir(type,owner,host_os, account_str):  
  sudo = getsudo(account_str,host_os, type, owner)
  mkdir = getcmd('mkdir',host_os)
  return sudo + mkdir
        
def getrm(type, host_os, owner, account_str):
  sudo = getsudo(account_str,host_os, type, owner)
  rm = getcmd('rm',host_os)
  return sudo + rm

def logmsg(msg, level, logger): 
  if level == logging.DEBUG:
    logger.debug(msg)
    return
  if level == logging.INFO:
    logger.info(msg)
    return
  if level == logging.WARNING:
    logger.warning(msg)
    return
  logger.error(msg)
  
def logresult(result,logger):
  for host in result:
    logmsg(host, debug,logger)     
    logmsg(result[host], debug, logger)
    
def printresult(result,logger):   
  logandprint(result, debug, logger)
    
def populateresult(result,status, message, host_name, level, backup_success, options,logger):   
  logmsg('in populate result %s'%message, level, logger)
  ret ={}  
  ret['status'] = status
  backup_msg = ''
  operation = options.operation
  if backup_success != None and host_name != 'source' and backup_success[host_name] == 'False' and operation == 'commit':
    backup_msg = 'Backup failed: '  
  elif backup_success != None and host_name != 'source' and backup_success[host_name] != 'False' and operation == 'commit':
    logmsg('getting backupfiles for host %s %s'%(host_name,backup_success[host_name]),debug, logger)
    backup_msg = 'Backup completed, archive file:  ' + backup_success[host_name] + '\n'  
  ret['result'] = backup_msg + message
  result[host_name]=ret
  
def logandprint(msg,level, logger): 
  logmsg(msg,level,logger)
  print msg

def getarchpattern(archive_backup_dir): 
  head,tail = os.path.split(archive_backup_dir) 
  pattern = tail.split('.')[0] + '*.tar.gz'
  return pattern

def getarchbackupdir(options):
  head,tail = os.path.split(options.backup_dir)
  if len(tail) == 0:
    return options.backup_dir+'dns_backup_archives_amp'
  else:
    return options.backup_dir+'/dns_backup_archives_amp'
  
#match pattern for file changes list
def pattern(type): 
  start_pattern = ''
#   if 'APN' in type:
#     start_pattern = 'sending incremental'
# when -m is used to exclude empty directories, start pattern changes
#   else:
  start_pattern = 'building file list'
  return start_pattern,'sent '

def getdiff(output, dns_base, host_os, logger):
  start_pattern, end_pattern = pattern(host_os)
  ret = []
  head, tail = os.path.split(dns_base)
  if output == None:
    return ret
  outputList = output.split('\n')
  start = False
  logmsg('tail %s'%tail, debug, logger)  
  for entry in outputList:
    if not entry.startswith(start_pattern) and not start:
      continue
    elif entry.startswith(start_pattern) and not start:
      start = True
      continue
    elif entry.startswith(end_pattern):
      break
    elif entry.startswith('skipping'):
      continue
    elif len(entry.strip()) == 0:
      continue
    elif start:
      ret.append(entry)          
  return ret

def logoptions(options,logger):
  logmsg('options passed in', info,logger)
  logmsg(options, info, logger)

def formetifile(ifile,dns_base):
  ret = ''
  tmp = ifile[ifile.startswith(dns_base) and len(dns_base):]
    
  if not os.path.isabs(tmp):
    ret += '/'
  ret += tmp
  head, tail = os.path.split(tmp)
  if tail == '': 
    ret += '**'
  return ret

def logbackupsuccess(backup_success, logger):
  logmsg('backup_success dict', debug, logger)
  if backup_success != None:
    for host_name, success in backup_success.iteritems():
      logmsg('host %s value %s'%(host_name,success), debug, logger)
    
  
def initbackupsuccess(hosts, operation):
  ret = {}
  ret['source'] = 'True'
  for host in hosts:
    if operation == 'commit':
      ret[host['name']] = 'False'
    else:
      ret[host['name']] = host['backup-success']
  return ret

def getdnsbase(type, options):
  if 'FN' in type:
    return options.fn_dns_base
  else:
    return options.dns_base

def getdnsdestbase(type, options):
  if 'FN' in type:
    return options.fn_dest_base_dir
  else:
    return options.dns_base
  
def getvalues(instr):
  if instr == None or len(instr) == 0:
    return []
  in_dict = json.loads(instr) 
  ret = [f['name'] for f in in_dict]
  return ret

def getexcludes(type,options):
  if type == 'APN':
    return options.symbolic_link, getvalues(options.exclude_files)
  if type == 'FN-APN':
    return options.fn_symbolic_link, getvalues(options.fn_exclude_files)
  return None, []

def tologlevel(level_str):
  level = level_str[level_str.find('-')+1:]
  choices = {
    'debug': debug, 
    'info': info,
    'warning': warning,
    'error': error
    }
  return choices.get(level, 'default')

def getfilemtime(file):
  try:
    epoch = int(file.split('.')[1])    
    return file + ' created at ' + time.strftime("%Y-%m-%d %H:%M %Z", time.localtime(epoch)) 
  except IndexError:
    return "incorrect file name"
  except:
    raise
    return None

def checkdups(hosts):
  if hosts == None:
    return False, None
  seen_name = [] 
  seen_ip = []  
  for host in hosts:
    if host['name'] not in seen_name:
      seen_name.append(host['name'])
    else:
      return True, host['name']
    if host['ip'] not in seen_ip:
      seen_ip.append(host['ip'])
    else:
      return True, host['ip']
  return False, None

def getcmd(cmd,host_os):
  if validos(host_os):
    return cmd_tbl[cmd][host_os]
  else:
    return ' '
  
def validos(host_os):
  if host_os == None:
    return False
  return host_os == 'SunOS' or host_os == 'Linux'

    