def initstaging(hostcmd): 
  common.cleandir(hostcmd, staging_dir, rootlogger) 
  common.synclocal(hostcmd,options.dns_base,staging_dir,rootlogger)
    
def syncstagetosrc(hostcmd, ixc): 
  head,tail = os.path.split(options.dns_base)
  src = staging_dir +  "/" + tail
  dest = head
  common.synclocal(hostcmd,src, dest, rootlogger)
  common.removedir(hostcmd,staging_dir,rootlogger)
  
def makeTempDir(cmd_handler):
  
  for dir in ['get_diff', 'make_backup_dir', 'purge_backups', 'stage_files']:
    cmd = 'mkdir -p ' + temp_dir + '/' + dir
    cmd_handler.execlocalcmd(cmd)

def restorefrombackup(hostcmd):  
  backup_archive = getlatestbackup(hostcmd)
  util.logmsg('latest backup archive %s'%backup_archive, debug, rootlogger)
  
  common.cleandir(hostcmd, tmp_backup_dir, rootlogger)  
  cmd = "mkdir -p " + tmp_backup_dir
  hostcmd.execremotecmd(cmd)    
  #extract from archive, tar zxvf /tmp/dns_backup_archives_amp/amp_syncdns_backup.1504733888.tar.gz -C /tmp/dns_backup_archives_amp/  
  cmd = util.gettar(hostcmd.remote_os) + " zxvf " + backup_archive + " -C " + tmp_backup_dir
  hostcmd.execremotecmd(cmd)  
  file_name = backup_archive.split('/')[-1]
  head,tail = os.path.split(options.dns_base)
  src = tmp_backup_dir+'/' + file_name.split('.')[0] +'.'+ \
  file_name.split('.')[1] + '/' + tail
  dest = head
  common.synclocal(hostcmd,src, dest, rootlogger)
     
def stagefiles(hostcmd): 
  util.logmsg('start staging for host %s'%hostcmd.remote_ip, info, rootlogger)
  #run rsync from local 
  param = ''
  # -a = -rlptgoD
  rsyncflag = '-rgoDvzc' 
  if not ixc:
    #sync apn, from dns_base
    if options.exclude_files != None:
      # add this if we want to create empty dir, risk --include '*/'
      efiles = options.exclude_files.split(',')
      for efile in efiles:
        param += ' --exclude ' + efile + ' '
    if options.symbolic_link != None and options.symbolic_link != "True":
      rsyncflag += 'l'
  else:
    #sync ixc files
    
    if options.ixc_files != None:
       
      ifiles = option.ixc_files.split(',')
      if len(ifiles) > 0:
        param += "-m --include='*/' "
      for ifile in ifiles:
        param +="--include = '" + ifile + "' "
      if len(ifiles)  > 0:
        param += " --exclude='*'"
        
  param += " --delete " + rsyncflag + " " + options.dns_base + " " + hostcmd.remote_ip + ":"+ staging_dir 
  util.logmsg('rsync param %s send to host %s'%(param,hostcmd.remote_ip), debug, rootlogger)
  return common.syncremote(hostcmd, param, rootlogger)

def syncremote(hostcmd,param, logger):
  util.logmsg('cmd param to sync from master to target %s from  param %s '%(hostcmd.remote_ip,param),util.info, logger)
  option = {}
  option['fcmd']='rsync'
  option['key'] = util.getrrsynckey()
  return hostcmd.execlocalfcmd(param,option)

def getmd5cmd(os):
  if 'Sun' in os:
    return 'digest -a md5'  
  else:
    return 'md5sum'
  
def getmd5(fileList):
  m = hashlib.md5()
  m.update(fileList)
  return m.digest()


def get_srcfp(hostcmd, difflist, base):  
  md5cmd = util.getmd5cmd(hostcmd.local_os)
  head, tail = os.path.split(base)
  file_fp =''
  for diff in difflist:
    if not os.path.isfile(diff):
      file_fp += diff
    else:
      cmd = md5cmd + ' ' + head + '/' + diff 
      output = hostcmd.execlocalcmd(cmd)
      file_fp += output.split()[0]
  return util.getmd5(file_fp)

def get_hostfp(hostcmd, difflist,base):
  md5cmd = util.getmd5cmd(hostcmd.remote_os)
  head, tail = os.path.split(base)
  file_fp =''
  for diff in difflist:
    if not os.path.isfile(diff):
      file_fp += diff
    else:
      cmd = md5cmd + ' ' + head + '/' + diff 
      output = hostcmd.execremotecmd(cmd)
      file_fp += output.split()[0]
  return util.getmd5(file_fp)

def getos(local, hostcmd,logger):  
  cmd = '/bin/uname'
  cmd2 = 'uname'
  try:
    if local:
      return hostcmd.execlocalcmd(cmd)
    return hostcmd.execremotecmd(cmd)
  except SyncCmdExecError as e:
    try:
      if local:
        return hostcmd.execlocalcmd(cmd2)
      return hostcmd.execremotecmd(cmd2)
    except:
      if local and hostcmd.local_os != None:
        return hostcmd.local_os
      elif hostcmd.host != None and hostcmd.host.os != None:
        return hostcmd.host.os
      else:
        raise    
  except:
    if local and hostcmd.local_os != None:
        return hostcmd.local_os
    elif hostcmd.host != None and hostcmd.host.os != None:
      return hostcmd.host.os
    else:
      raise