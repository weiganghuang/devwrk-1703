import commands
import sys
import os
from optparse import OptionParser,OptionError
import logging
from threading import Thread
import time
import hashlib
import util
import json
from sync_command import SyncCmdExecError, SyncCommand, SyncTimeoutError
from version import VERSION
import common

LOG_FILENAME ='/var/tmp/amp_sync_script_log'
logging.basicConfig(level=logging.DEBUG,
                    format='<%(levelname)s> %(asctime)s.%(msecs)03d %(message)s',
                    datefmt='%d-%m-%Y %Z %H:%M:%S',
                    filename='/var/tmp/amp_sync_script_log',
                    filemode='w')
rootlogger = logging.getLogger(__name__)
fail = 'FAILED'
success = 'SUCCESS'
timestamp = str( int(time.mktime(time.localtime())))
tmp_backup_dir = '/var/tmp/amp_tmp_backup' 
local_os = ''
archive_backup_dir = '' 
options = None
result = {}
backup_success = {}

class Worker(Thread): 
      
  def __init__(self, host):
    Thread.__init__(self)
    self.host = host 
    self.e = None
    self.hostcmd = None
    if host != None:
      self.name = host['name']
    
   
  def run(self): 
    global result  
    host_name = self.host['name']
    try:
      is_local = False
      try: 
        self.hostcmd = SyncCommand(local_os, host, options.account, rootlogger) 
      except:
        util.logmsg('got exception in getting os of target', util.error, rootlogger)
        if options.operation == 'commit':
          backup_success[host_name] = 'False'
        raise
          
      if options.operation == 'commit' :
        performcommit(self.host,self.hostcmd) 
      elif options.operation == 'rollback':
        performrollback(self.host,self.hostcmd)
      self.output = 'result'
      
    except SyncCmdExecError as e:
      util.populateresult(result,fail, '%s %s status %s'%(e.expr,e.msg,e.status), host_name, util.error, backup_success,options,rootlogger)
      self.e = e
          
    finally:
      #clean up, if we get exception, log the error
      try:
        common.removedir(self.hostcmd,tmp_backup_dir,rootlogger)
        common.removedir(self.hostcmd,archive_backup_dir,rootlogger)
      except SyncCmdExecError as e:
        util.logmsg('clean up tmp directory failed with %s %s '%(e.expr,e.msg), util.error, rootlogger)
      except:
        util.logmsg('clean up tmp directory failed with %s '%('Error: {}'.format(sys.exc_info()[0])), util.error, rootlogger)
    
def performrollback(host,hostcmd):
  global result  
  host_name = host['name'] 
  if backup_success[host_name] == 'False':
    util.populateresult(result, success, 'Roll back not performed, previous backup failed', host_name, util.info, None, options,rootlogger)
    return
   
  output, backup_archive = restorefrombackup(hostcmd)  
  difflist = util.getdiff(output, util.getdnsbase(hostcmd.host_type, options),hostcmd.host_type,rootlogger)
  if len(difflist) == 0:
    util.populateresult(result,success,'Rolled back from %s\nNo difference found'%util.getfilemtime(backup_archive),host_name, util.info, None,options, rootlogger)
  else:
    syncresult = "\n".join(difflist)  
    util.populateresult(result,success,'Rolled back from: %s\n Files rolled back\n%s'%(util.getfilemtime(backup_archive),syncresult), host_name, util.info,None,options,rootlogger)
           
def performcommit(host, hostcmd): 
  
  global result
  host_name = host['name']
  try:
    takebackup(hostcmd)
    backup_file = archivebackup(hostcmd)
    backup_success[host_name] = util.getfilemtime(backup_file)
    
  except:
    util.logmsg('got exception in backing up', util.error, rootlogger)
    backup_success[host_name] = 'False'
    raise

  output = syncfiles(hostcmd)      
  difflist = util.getdiff(output, util.getdnsbase(hostcmd.host_type, options),hostcmd.host_type,rootlogger)
  if len(difflist) == 0:
    util.populateresult(result,success, 'No difference found', host_name, util.info, backup_success, options,rootlogger)  
  else:
    syncresult = "\n".join(difflist)  
    util.populateresult(result,success,'Files synced \n%s '%syncresult, host_name, util.info, backup_success, options,rootlogger)
  

def getlatestbackup(hostcmd):  
  ls = util.getcmd('ls',hostcmd.remote_os)
  head = util.getcmd('head',hostcmd.remote_os)
  cmd = ls + " -t " + util.getarchbackupdir(options) + "*.tar.gz | " + head + " -1"  
  return hostcmd.execremotecmd(cmd)
 

def takebackup(hostcmd):  
  cmd = util.getmkdir(hostcmd.host_type, hostcmd.remote_owner, hostcmd.remote_os, hostcmd.account_str) + " -p " + archive_backup_dir
  hostcmd.execremotecmd(cmd)
  src = util.getdnsdestbase(hostcmd.host_type, options)
  head,tail = os.path.split(src)
  dest = archive_backup_dir + "/" + tail
  common.synclocal(hostcmd, options, src, dest, rootlogger)

def archivebackup(hostcmd): 
  tar = util.gettar(hostcmd.remote_os, hostcmd.host_type, hostcmd.remote_owner, hostcmd.account_str)
  head, tail = os.path.split(archive_backup_dir)
  cmd = tar + " -C " + options.backup_dir + " --remove-files --warning=no-file-changed " + " -zcf " \
  +  archive_backup_dir + ".tar.gz "  + tail 
  hostcmd.execremotecmd(cmd)
  purgebackups(hostcmd)
  return archive_backup_dir + ".tar.gz"
 

def purgebackups(hostcmd): 
  max_version = None
  max_size = None
  if options.max_version == None and options.max_size == None:
    return
  if options.max_version != None:
    max_version = int(options.max_version)
    if max_version <= 0:
      max_version = 1  
  if options.max_size != None and options.max_size.isdigit():
    max_size = int(options.max_size)*1000
  
  file_pattern = util.getarchpattern(archive_backup_dir)
  find = util.getcmd('find',hostcmd.remote_os)
  ls = util.getcmd('ls',hostcmd.remote_os)
  cmd = find + " "+ options.backup_dir  + \
    " -type d ! -perm -g+r,u+r,o+r -prune -o -name \"" + file_pattern + "\" -exec " + \
    ls + " -1rt \"{}\" +;"  
  output = hostcmd.execremotecmd(cmd)
  i=0  
  file_list = output.split('\n')
  #remove files until it meets the  allowed versions
  if max_version != None:
    to_delete = len(file_list) - max_version
    cmd = util.getrm(hostcmd.host_type, hostcmd.remote_os, hostcmd.remote_owner,hostcmd.account_str)
    file_names = ''  
    for file in file_list:
      if i < to_delete and len(file.strip()) >0:
        file_names += " " + file
        i += 1
    if len(file_names) > 0:
      cmd += file_names 
      hostcmd.execremotecmd(cmd)
  
  #continue to check the size, make sure we have at least one archive.
  if max_size != None:
    if i<len(file_list):
      du = util.getcmd('du',hostcmd.remote_os)
      du_cmd = du + " -s " + options.backup_dir + " 2> /dev/null" 
      du_files = file_list[i:]
      remains = len(du_files)      
      for file in du_files: 
        if remains <= 1:
          return
        output = hostcmd.execremotecmd_ignorestatus(du_cmd,256)   
        current_size = output.split()[0]
        if current_size != None and current_size.isdigit() and int(current_size) > max_size and len(file.strip()) >0:
          cmd = util.getrm(hostcmd.host_type, hostcmd.remote_os, hostcmd.remote_owner, hostcmd.account_str) + " " +  file
          hostcmd.execremotecmd(cmd)
          remains -= 1
        else:
          break  
        
def restorefrombackup(hostcmd):  
  
  backup_archive = getlatestbackup(hostcmd)
  util.logmsg('latest backup archive %s'%backup_archive, util.debug, rootlogger)
  
  common.removedir(hostcmd, tmp_backup_dir, rootlogger) 
  cmd = util.getmkdir(hostcmd.host_type, hostcmd.remote_owner, hostcmd.remote_os, hostcmd.account_str) + " -p " + tmp_backup_dir
  hostcmd.execremotecmd(cmd)    
  cmd = util.gettar(hostcmd.remote_os, hostcmd.host_type, hostcmd.remote_owner,hostcmd.account_str) + " zxf " + backup_archive + " -C " + tmp_backup_dir
  hostcmd.execremotecmd(cmd)  
  file_name = backup_archive.split('/')[-1]
  dns_dest_base = util.getdnsdestbase(hostcmd.host_type, options)
  head,tail = os.path.split(dns_dest_base)
  src = tmp_backup_dir+'/' + file_name.split('.')[0] +'.'+ \
  file_name.split('.')[1] + '/' + tail
  dest = dns_dest_base
  return common.synclocal(hostcmd,options, src, dest, rootlogger), backup_archive
  
def syncfiles(hostcmd): 
  dns_base = util.getdnsbase(hostcmd.host_type, options)
  dns_dest = util.getdnsdestbase(hostcmd.host_type, options)
  return common.syncremote(hostcmd, options, dns_base, dns_dest, rootlogger)

def parseargs():
  global options,archive_backup_dir
  usage_str = "usage: %prog [options] arg"
  version_str = "%prog " + VERSION
  parser = OptionParser(usage = usage_str, version = version_str)
  parser.add_option('-s', '--servers', help = 'destination apn server list', dest = 'hosts')
  parser.add_option('-b', '--backup_directory', help = 'backup directory', dest='backup_dir')
  parser.add_option('-d', '--dns_base', help = 'dns sync base directory', dest = 'dns_base')
  parser.add_option('-t', '--oper_type', help = 'operation type, commit or rollback',dest = 'operation')
  parser.add_option('-e', '--exclude_files', help = 'excluded files', dest = 'exclude_files')
  parser.add_option('-i', '--include_files', help = 'include files, applies to ixc targets', dest='ixc_files')
  parser.add_option('-l', '--symbolic_link', help = 'symbolic link excluded?', dest = 'symbolic_link')
  parser.add_option('-n', '--max_versions', help = 'maximum versions of backup kept', dest = 'max_version')
  parser.add_option('-m', '--max_size',help = 'maximum backup disk size (MB)', dest = 'max_size')
  parser.add_option('-T', '--exec_timeout', help = 'script execution timeout (seconds)', dest = 'timeout')
  parser.add_option('-a', '--user_accounts', help = 'user accounts for forced commands', dest = 'account')
  parser.add_option('-f', '--fn_dns_base', help = 'first net dns sync base directory', dest = 'fn_dns_base')
  parser.add_option('-g', '--fn_exclude_files',help = 'first net exclude files', dest = 'fn_exclude_files')
  parser.add_option('-j', '--fn_symbolic_link', help = 'first net, symbolic link excluded?', dest = 'fn_symbolic_link')
  parser.add_option('-k', '--log_level', help = 'log level', dest = 'log_level')
  parser.add_option('-o', '--local_os', help = 'master os, SunOS or Linux',dest = 'local_os')
  parser.add_option('-r', '--fn_dest_base_dir', help='first net dns sync destination base directory', dest='fn_dest_base_dir')
  
  try: 
    (options, args) = parser.parse_args()  
    util.logoptions(options, rootlogger) 
    if options.hosts == None or \
    options.backup_dir == None or \
    options.dns_base == None or \
    options.account == None or \
    options.operation == None:
        parser.print_help()
        return False 
    archive_backup_dir = util.getarchbackupdir(options) + '.'+ timestamp
    return True
  except OptionError :
    parser.print_help()
    return False

if __name__ == '__main__' : 
  
  if not parseargs():   
    util.populateresult(result,fail,'input parameters, missing mandatory parameters!', 'source', util.error, None, options, rootlogger)   
    sys.exit()
  local_cmd = SyncCommand(options.local_os,None,options.account,rootlogger)  
  try: 
    if options.log_level != None:
      log_level = util.tologlevel(options.log_level)
      rootlogger.setLevel(log_level)
    is_local = True
    local_os = local_cmd.local_os  
    threads = []
    if options.hosts != None:
      hosts = json.loads(options.hosts)
      dups,duphost = util.checkdups(hosts)
      if dups:
        util.populateresult(result,fail, 'duplicate destination found %s'%duphost, 'source',util.error, None, options,rootlogger)
        sys.exit()
      backup_success = util.initbackupsuccess(hosts,options.operation)
      util.logbackupsuccess(backup_success, rootlogger)
      for host in hosts:
        worker = Worker(host)
        #worker.daemon = True
        threads.append(worker)   
        worker.start()           
        time.sleep(0.2)
        
      time_out = int(options.timeout)
      if time_out <= 0:
        time_out = None
      elif time_out < 5:
        time_out = 5
      for t in threads:     
        t.join(time_out)  
          
      for t in threads:
        if t.is_alive() and t.e == None:            
            t.e = SyncTimeoutError(t.name, 'sync operation timed out','sync operation timed out',0) 
            if options.operation == 'rollback':
              util.populateresult(result,fail, 'sync operation timed out', t.name, util.error, None,options,rootlogger)
            else:
              util.populateresult(result,fail, 'sync operation timed out', t.name, util.error, backup_success,options, rootlogger)                             
        else:
           util.logmsg('thread %s complete'%t.name,util.debug, rootlogger)  
            
      for t in threads:
        util.logmsg('in thread checking %s '%t.name, util.debug, rootlogger)
        if t.e != None:
          util.logmsg('thread %s raise exception'%t.name,util.debug, rootlogger)   
          raise t.e 
              
    j_result = json.dumps(result)
    util.logmsg('result %s'%j_result, util.debug, rootlogger)
    util.printresult(j_result,rootlogger)
      
  except SyncCmdExecError as cmderror:
    util.populateresult(result,fail, 'error %s %s status %s '%(cmderror.expr,cmderror.msg, cmderror.status), cmderror.source,util.error, backup_success,options, rootlogger)
    j_result = json.dumps(result)
    util.printresult(j_result,rootlogger)
  
  except SyncTimeoutError as timeouterror:
    util.logmsg('sync timeout exception expr %s msg %s source %s'%(timeouterror.expr,timeouterror.msg, timeouterror.source), util.error, rootlogger )
    j_result = json.dumps(result)
    util.printresult(j_result,rootlogger)
  
  except SystemExit:
    util.logmsg('faital error, exit', util.error, rootlogger)  
    j_result = json.dumps(result)
    util.printresult(j_result,rootlogger)
    
  except :
    util.printresult('other exception: %s'%sys.exc_info()[0],  rootlogger)
    raise
    
  finally:
    pass
    
  