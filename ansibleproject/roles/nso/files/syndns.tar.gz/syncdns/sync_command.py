import commands
import util


class SyncCommand():
	def __init__(self, local_os, host, account_str, logger):
		self.host = host		
		if host == None:
			self.remote_name = 'source'	
		else:	
			self.remote_ip = self.host['ip']
			self.remote_name = self.host['name']
			self.host_type =  self.host['server-type']
			self.remote_owner = self.host['owner']
			self.remote_configgedos = self.host['os']			
		self.account_str = account_str
		self.logger = logger
		self.local_os = self.getos(local_os,True)
		if host != None:
			self.remote_os = self.getos(self.remote_configgedos,False)
	
	def execlocalcmd(self,incmd):
		cmd = incmd
		status, output = commands.getstatusoutput(cmd)		
		if status > 0:
			util.logmsg('local command sent: %s, status %s, output %s'%(cmd,status,output), util.error, self.logger)
			raise SyncCmdExecError('source','cmd %s failed'%cmd,output,status)
		else:
			util.logmsg('local command sent: %s, status %s, output %s'%(cmd,status,output), util.debug, self.logger)
		return output
	
	def	execremotecmd_ignorestatus(self,incmd,istatus):
		try:
			return self.execremotecmd(incmd)
		except SyncCmdExecError as e:
			if e.status != istatus:
				raise e
			else:
				return e.msg
	
	def execremotecmd(self,incmd):
		if self.local_os == None or self.remote_ip == None:
			raise SyncCmdExecError('source','not able to execute remote command '%incmd, 'remote os and/or remote ip not set')
		df_key = util.getdefaultkey(self.account_str)
		cmd = util.getssh(self.local_os) + " -i " + df_key + " "  + \
			self.remote_ip + " '"+ incmd +"'"
		status,output = commands.getstatusoutput(cmd)		
		if status > 0:
			util.logmsg('remote command sent to %s: %s, status %s, output %s'%(self.remote_ip, cmd,status,output), util.error, self.logger)
			raise SyncCmdExecError(self.remote_name,'remote cmd: %s failed'%incmd,output,status)
		else:
			util.logmsg('remote command sent to %s: %s, status %s, output %s'%(self.remote_ip, cmd,status,output), util.debug, self.logger)
		return output

# this is rsync command to do local backup at targets
	def execremotersynccmd(self,param, type):
		remotecmd = util.getrsync(self.remote_os, type, self.remote_owner, self.account_str) + " " + param 
		df_key = util.getdefaultkey(self.account_str)
		cmd = util.getssh(self.local_os) + " -i " + df_key + " "  + \
			self.remote_ip + " \"" + remotecmd + "\""
		status,output = commands.getstatusoutput(cmd)
		if status > 0:
			util.logmsg('remote command sent to %s: %s, status %s, output %s'%(self.remote_ip, cmd,status,output), util.error, self.logger)
			raise SyncCmdExecError(self.remote_name,
														'remote cmd: %s failed'%remotecmd, output,status)
		else:
			util.logmsg('remote command sent to %s: %s, status %s, output %s'%(self.remote_ip, cmd,status,output), util.debug, self.logger)
		return output
	
# this is forced rsync from master to target
	def execlocalfcmd(self,param,type):
		
		rrsync_key = util.getrrsynckey(self.host_type, self.remote_owner,self.account_str)
		cmd = util.getxrsync(self.local_os) + " -e '"+ util.getssh(self.local_os)  + \
		" -i " + rrsync_key + "' "+ param 
		status,output = commands.getstatusoutput(cmd)		
		if status > 0:
			util.logmsg('local forced command sent: %s, status %s, output %s'%(cmd,status,output), util.error, self.logger)
			raise SyncCmdExecError(self.remote_name,
														'local force cmd: %s failed'%cmd, output,status)
		else:
			util.logmsg('local forced command sent: %s, status %s, output %s'%(cmd,status,output), util.debug, self.logger)
		return output
	
	def setlocalos(self,local_os):
		self.local_os = local_os
		
	def setremoteos(self,remote_os):
		self.remote_os = remote_os
		
	def setremoteip(self,remote_ip):	
		self.remote_ip = remote_ip
	
	def getos(self, in_os,local):
		try:
			if util.validos(in_os):
				return in_os
			cmd = '/bin/uname'
			cmd2 = 'uname'
			ret_os = ''
			if local:
				return self.execlocalcmd(cmd)
			return self.execremotecmd(cmd)			
		except SyncCmdExecError as e:
			try:
				if local:
					return self.execlocalcmd(cmd2)
				return self.execremotecmd(cmd2)
			except:
				raise  
		except:
			raise
      
      
class Error(Exception):
	pass

class SyncCmdExecError(Error):
	def __init__(self,source,expr,msg,status):
		self.source = source
		self.expr = expr
		self.msg = msg
		self.status = status
		
class SyncTimeoutError(Error):	
	def __init__(self,source,expr,msg,status):
		self.source = source
		self.expr = expr
		self.msg = msg
		self.status = status
		
		

	
