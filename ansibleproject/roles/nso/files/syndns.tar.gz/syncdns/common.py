import util
import os
from sync_command import SyncCmdExecError, SyncCommand


#rsync local, from src to dest, remote command (at target)
def synclocal(hostcmd, options, src_dir,dest_dir,logger):
  type = hostcmd.host_type
  param = syncparam(type,options,logger)
  param += " " + src_dir + "/ " + dest_dir
  util.logmsg('rsync param %s send to host %s'%(param,hostcmd.remote_ip), util.debug, logger)
  return hostcmd.execremotersynccmd(param,type)
  
#rsync master to destination,  local command (at master )  
def syncremote(hostcmd,options, src_dir, dest_dir, logger):
  type = hostcmd.host_type
  param = syncparam(type,options, logger)  
  param += " " + src_dir + "/ " + hostcmd.remote_ip + ":"+ dest_dir 
  return hostcmd.execlocalfcmd(param,type)

#remove dir, at target
def removedir(hostcmd,dir,logger):
  cmd = util.getrm(hostcmd.host_type,hostcmd.remote_os, hostcmd.remote_owner,hostcmd.account_str) + " -rf " + dir + " 2>/dev/null"
  util.logmsg('remove dir %s for host %s cmd %s'%(dir,hostcmd.remote_ip,cmd),util.debug,logger)
  return hostcmd.execremotecmd(cmd)

def syncparam(type,options,logger):
  param = ''
  # -a = -rlptgoD
  rsyncflag = '-rvzcm' 
  if 'APN' in type:
    slink, exclude_files = util.getexcludes(type,options)
    #sync apn, from dns_base
    if exclude_files != None and len(exclude_files) >0 :
      # add this if we want to create empty dir, risk --include '*/'      
      for efile in exclude_files:
        param += ' --exclude \''  + efile + '\' '
        
    if slink != None and slink != "True":
      rsyncflag += 'l'
  else:
    
  #sync ixc files
  #rsync  -e '/usr/localcw/bin/ssh -i .ssh/id_rsa_m94644_rrsync' -m --include='*/' --include='/master/apn*' --include='/master/epc/**' --exclude='*' --delete -rgoDvzc /usr/local/bind9/ /tmp/test_wg_1
    
    if options.ixc_files != None:    
      ifiles = util.getvalues(options.ixc_files)  
      if ifiles != None and len(ifiles) > 0:
        param += "--include='*/' " 
        for ifile in ifiles:
          param +="--include='" + util.formetifile(ifile,options.dns_base) + "' "    
        param += " --exclude='*'" 
#         rsyncflag += 'm'
  param += " " + rsyncflag 
  return param

