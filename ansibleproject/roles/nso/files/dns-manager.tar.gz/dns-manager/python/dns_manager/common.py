import ncs
import os
import json
from account import account
import commands

def process_result(result):
  if result == None:
    return None
  host_results = result.split(',')  
  
def norm_path(inpath):
    if inpath == None:
      return
    head,tail = os.path.split(inpath)
    if len(tail) == 0:
      return head
    else:
      return inpath   
     
def exec_cmd(log, cmd, exec_config): 
  exec_in = exec_config.get_input()
  exec_in.args = [cmd]
  ret = exec_config.request(exec_in)
  log.debug('command cmd %s, result: %s' %(cmd,ret.result))
  return ret.result  

def build_serverinfo(log,root):
  ret = {}
  log.debug('log inventory server info')
  try:
    nws = root.inventory.network_service
    for nw in nws:
      dcs = nw.data_center
      for dc in dcs:
        for dns in dc.dns_server:
          ret[dns.name] = (str(dns.os), str(dns.owner))
    log_serverinfo(log,ret)
    return ret
  except:
    raise
    return None   

def log_serverinfo(log,serverinfo): 
   
  if serverinfo == None or len(serverinfo) == 0:
    log.debug('empty inventory server info')
  for server, (svr_os, svr_owner)  in serverinfo.iteritems():
    log.debug('server %s, os %s, owner %s'%(server,svr_os,svr_owner))

  
def get_exec(log, root, serverinfo, input): 
  if serverinfo == None or len(serverinfo) == 0:
    return -1, 'empty inventory', None,None,None
  if input['source'] not in serverinfo.keys():
    return -1, 'source ' + input['source'] + ' not in NCS DNS Sync inventory \n',None, None, None  
  src_os, src_owner = serverinfo[input['source']]
  log_level = root.python_vm.logging.level
  log_prefix = root.python_vm.logging.log_file_prefix
  srcdevice = device = root.devices.device[input['source']]
  return log_level, log_prefix, srcdevice.address, src_os, srcdevice.config.unix_bind__EXEC.unix_bind__exec
    
def validate_ned(log, device):
  if device.device_type == None:
    return False
  if device.device_type.generic == None:
    return False
  if device.device_type.generic.ned_id == None:
    return False
  if device.device_type.generic.ned_id != 'unix-bind':
    return False
  return True

def get_hosts(log, root, serverinfo, input ):
  ret = []
  seen = []
  destinations = input['destinations']
  if destinations != None and len(destinations) >0 :
    for dest in destinations:
      if dest.name == input['source']:
        log.warning('source %s in destination list, skip '%dest.name)
        continue
      
      if dest.name not in serverinfo:
        log.error('sync target %s not in inventory, check inventory!'%dest.name)
        return False, '', 'sync target %s not in inventory, check inventory!'%dest.name
      
      if dest.name not in seen:
        seen.append(dest.name)
      else:
        log.error('duplicate destination found: %s!'%dest.name)
        return False, '', 'duplicate destination found: %s!'%dest.name
      
      device= root.devices.device[dest.name] 
      if not validate_ned(log,device):
        log.warning('Skip non unix-bind destination %s'%dest.name)
        continue
      
      if device.address not in seen:
        seen.append(device.address)
      else:
        log.error('duplicate destination found: %s ip %s, check inventory!'%(dest.name,device.address))
        return False, '', 'duplicate destination found: %s ip %s, check inventory!'%(dest.name, device.address)
      
      dest_os, dest_owner = serverinfo[dest.name]
      destitem = {}
      destitem['ip'] = device.address
      destitem['name'] = dest.name 
      destitem['owner'] = dest_owner
      destitem['os'] = dest_os
      if 'FN' in str(dest.server_type) and (input['fn-dns-base'] == None 
                                            or len(input['fn-dns-base']) == 0):
        return False, '', 'fn-dns-base not provided for First Net APN target %s'%dest.name 
      
      if 'FN' in str(dest.server_type) and (input['fn-dest-base-dir'] == None 
                                            or len(input['fn-dest-base-dir']) == 0):
        return False, '', 'fn-dest-base-dir not provided for First Net APN target %s'%dest.name 
        
      if 'IXC' in str(dest.server_type) and (input['ixc-files'] == None 
                                            or len(input['ixc-files']) == 0):
        return False, '', 'ixc files not provided for IXC target %s'%dest.name                                            
      destitem['server-type'] = str(dest.server_type)
      destitem['backup-success'] = str(dest.backup_success)
      ret.append(destitem)
  if ret == None or len(ret) == 0:
    log.error('no dns servers in inventory')
    return False, '', 'No DNS servers (unix-bind) in inventory!'
  log.debug('serialize dests: %s'%json.dumps(ret))
  return True, json.dumps(ret), ''

def get_files(file_list, log):
  ret = []
  for file in file_list:
    fileitem = {}
    fileitem['name'] = file
    ret.append(fileitem)
  log.debug('serialize pattern list: %s'%json.dumps(ret))
  return json.dumps(ret)

def getsudo(src_os):
  if src_os == None:
    return 'sudo'
  if 'Sun' in src_os:
    return '/usr/localcw/opt/sudo/bin/sudo'
  if 'Linux' in src_os:
    return '/usr/bin/sudo'
  else:
    return 'sudo'
  
def build_cmd(log, input, hosts, src_os, log_level):
  account_dict = json.loads(account)
  peeruser = account_dict['peer']
  sudo = getsudo(src_os)
  log.debug('sudo for python %s'%sudo)
  cmd = sudo + ' -u ' + peeruser + ' python ' + input['directory'] + '/' + 'syncdns.py' + \
  ' -s ' + "'" + hosts +"'"+ \
  ' -b ' + input['backup-directory'] + \
  ' -d ' + input['dns-base'] + \
  ' -t ' + str(input['operation'])  +\
  ' -a ' + "'" + account +"'" +\
  ' -o ' + src_os
  if input['exclude-files'] != None:
    cmd += ' -e ' + "'" + get_files(input['exclude-files'],log) + "'"
  if input['ixc-files'] != None:
    cmd += ' -i ' + "'" + get_files(input['ixc-files'],log) + "'"
  if input['exclude-softlink'] != None:
    cmd += ' -l ' + str(input['exclude-softlink'])
  if input['max-num-versions'] != None:
    cmd += ' -n ' + str(input['max-num-versions'])
  if input['max-disk-size'] != None:
    cmd += ' -m ' + str(input['max-disk-size'])
  if input['sync-timeout'] != None:
    cmd += ' -T ' + str(input['sync-timeout'])
  if input['fn-exclude-files'] != None:
    cmd += ' -g ' + "'" + get_files(input['fn-exclude-files'],log) + "'"
  if input['fn-exclude-softlink'] != None:
    cmd += ' -j ' + str(input[ 'fn-exclude-softlink'])  
  if input['fn-dns-base'] != None:
    cmd += ' -f ' + str(input[ 'fn-dns-base'])
  if input['fn-dest-base-dir'] != None:
    cmd += ' -r ' + str(input[ 'fn-dest-base-dir'])
  cmd += ' -k ' + str(log_level)
  log.debug('command to invoke python sync script %s'%cmd)
  return cmd
   
def log_input(log,input,keys):
  for key in keys:
    value = input[key]
    if key == 'destinations': 
      destinations = input['destinations']
      log.debug('destinations:')
      if destinations!= None and len(destinations)> 0 :
        for dest in destinations:
          log.debug('dest %s type %s backup-success %s'%(dest.name, dest.server_type,dest.backup_success))
    else:
      log.debug('%s: %s'%(key,value))
      
def action_error(message,details):
  err_details = {}
  err_result = {}            
  err_details['error'] = message
  err_details['details']= details
  err_result['ncs-action'] = err_details  
  return err_result

def add_extra_details(action_err, cmd_err,log):
  err_result = action_err['ncs-action']
  error = err_result['error'] + '\ncopy log file failed:' + cmd_err
  new_result = {}
  err_details = {}            
  err_details['error'] = error
  err_details['details']= err_result['details']
  new_result['ncs-action'] = err_details
  return new_result

#validating input
def validate_input(input, all_keys,log):     
    valid = True
    v_input = {} 
    iv_input = {}
    dir_keys = ['dns-base','directory','backup-directory','fn-dns-base','fn-dest-base-dir']
    for key in all_keys:
      if key in dir_keys:
        if input[key] != None and (not os.path.isabs(input[key])):
          iv_input[key] = input[key]
          valid = False
        else: 
          v_input[key] = norm_path(input[key])
      elif key == 'ixc-files' and input[key] != None:
        valid_ixc = True
        for ixc_file in input[key]:          
          if  not os.path.isabs(ixc_file):
            valid_ixc = False
            iv_input[key] = ixc_file
            break
        if valid_ixc:
          v_input[key] = input[key]
        else:
          valid = valid_ixc
      else:
        v_input[key] = input[key]
    
    
    if v_input != None:
      log_input(log,v_input,v_input.keys())
    
    if iv_input != None:
      log_input(log,iv_input,iv_input.keys())
    if valid:
      return valid, v_input, ''
    else:
      return valid, iv_input, 'directories must be absolute paths'    

def copy_log(log_prefix, src_ip, log):
  ssh_flag = " -o ConnectTimeout=5 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -q  "
  account_dict = json.loads(account)
  ncs_key = account_dict['ncs-key']
  peer = account_dict['peer']
  cmd = 'scp -i ' + ncs_key + ssh_flag + peer + '@'+ src_ip + ':/var/tmp/amp_sync_script_log /tmp'
  log.debug('cmd to copy log %s'%cmd)
  status, output = commands.getstatusoutput(cmd)
  log.debug('output %s status %s'%(output,status))
  if status > 0:
    log.error('copy log from master  cmd %s failed , output: %s'%(cmd, output))
    return status, 'copy log from master  cmd %s failed , output: %s'%(cmd, output)
  
  cmd = 'cat /tmp/amp_sync_script_log >> ' + log_prefix + '-syncdns.log'
  log.debug('cmd to cat log %s'%cmd)
  status, output = commands.getstatusoutput(cmd)
  log.debug('output %s status %s'%(output,status))
  if status > 0:
    log.error('copy log from master  cmd %s failed , output: %s'%(cmd, output))
    return status, 'copy log from master cmd %s failed , output: %s'%(cmd, output)
  return 0, ''
