account = '{"app": "named",' +\
          '"default-key": "/home/m14624/.ssh/m14624_Reg_comm",' +\
          '"peer": "m14624",' +\
          '"rrsync-key": "/home/m14624/.ssh/m14624_rrsync",' +\
          '"srsync-key": "/home/m14624/.ssh/m14624_sudorsync",' +\
          '"ncs": "m00254",' +\
          '"ncs-key": "/home/ncs/.ssh/m00254_id_Reg_comm"}'
