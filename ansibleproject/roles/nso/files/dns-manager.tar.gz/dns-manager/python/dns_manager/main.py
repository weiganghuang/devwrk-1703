# -*- mode: python; python-indent: 4 -*-
import ncs
import common
from ncs.application import Service
from ncs.dp import Action
import time
import _ncs
import os
import json
import commands

all_keys = ['backup-directory',
            'destinations',
            'directory',
            'dns-base',
            'exclude-files',
            'exclude-softlink', 
            'fn-dns-base',
            'fn-exclude-files',
            'fn-exclude-softlink',
            'ixc-files',
            'max-disk-size',
            'max-num-versions',            
            'operation',
            'source',
            'sync-timeout',
            'fn-dest-base-dir']
  
class Sync(Action):  
    
  @Action.action  
  def cb_action(self, uinfo, name, kp, input, output): 
    exec_config = None   
    self.log.debug('input parameters passed to action %s'%input.directory) 
    sync_timeout = int(input['sync-timeout']) if input['sync-timeout'] != None else 0
    
    _ncs.dp.action_set_timeout(uinfo,150 + sync_timeout) 
    common.log_input(self.log, input,all_keys)
    valid, saved_input, message = common.validate_input(input,all_keys,self.log)
    if not valid:
      output.result = json.dumps(common.action_error(message,saved_input))
      output.success = False
      return  
    log_prefix = '' 
    src_ip = '' 
    src_os = ''
    server_info = {}
    time.sleep(1)
    with ncs.maapi.Maapi() as m:
      with ncs.maapi.Session(m, uinfo.username, uinfo.context):
        with m.start_read_trans() as t:
          _ncs.dp.action_set_timeout(uinfo,150 + sync_timeout)       
          root = ncs.maagic.get_root(t)  
          serverinfo = common.build_serverinfo(self.log, root)
          log_level, log_prefix, src_ip, src_os, exec_config = common.get_exec(self.log,root, serverinfo,saved_input)  
          if log_level < 0:
            output.result = json.dumps(common.action_error(log_prefix, 'action error'))  
            output.success = False
            return      
          valid, hosts, message = common.get_hosts(self.log, root, serverinfo, saved_input)
          if not valid:
            output.result = json.dumps(common.action_error(message, 'action error'))
            output.success = False
            return 
          result = ''
          sync_cmd = common.build_cmd(self.log, saved_input, hosts, src_os,log_level)   
          result = common.exec_cmd(self.log, sync_cmd, exec_config)
          #t.finish()
          
    self.log.debug('result from cmd \n%s'%result)
    success = True
   
    if "STDERR" in result:    
      status, cmd_err = common.copy_log(log_prefix, src_ip, self.log)
      action_err = common.action_error(result, 'action error')
      output.result = json.dumps(action_err)
      output.success = False
      return
    if "FAILED" in result:
      output.success = False
    else:   
      output.success = True
    status, cmd_err = common.copy_log(log_prefix, src_ip, self.log)
    s_result = str(result)
    output.result = s_result[s_result.find('{'):]
    self.log.debug('output %s'%output.result)
    
# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')
        self.create_daemon('dns-manager')
        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        
        self.register_action('sync-action', Sync)
        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')
