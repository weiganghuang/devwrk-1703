account = '{"app": "dns",' +\
          '"default-key": "/home/m94644/.ssh/id_rsa_m94644",' +\
          '"peer": "m94644",' +\
          '"rrsync-key": "/home/m94644/.ssh/id_rsa_m94644_rrsync",' +\
          '"srsync-key": "/home/m94644/.ssh/id_rsa_m94644_sudorsync",' +\
          '"ncs": "m00254",' +\
          '"ncs-key": "/home/ncs/.ssh/m00254_id_rsa"}'
