#!/bin/bash

confd_cli -J --user=admin --groups=admin<<EOF
config private
exit
EOF
