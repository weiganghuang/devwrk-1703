#!/bin/bash

cat <<EOF
Version: 10
EOF
